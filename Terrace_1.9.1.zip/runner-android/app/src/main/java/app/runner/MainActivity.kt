package app.runner

import android.content.Intent
import android.net.Uri
import android.os.*
import android.provider.DocumentsContract
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.io.File
import kotlin.concurrent.thread

private val BG = Color(0xFF0E1116)
private val PANEL = Color(0xFF151A22)
private val ACC = Color(0xFF4FD1C5)
private val TXT = Color(0xFFD7DDE8)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(darkColorScheme(primary = ACC, background = BG, surface = PANEL)) { Screen() }
        }
    }

    private fun toPath(u: Uri): String {
        val (vol, rel) = DocumentsContract.getTreeDocumentId(u).split(":", limit = 2).let { it[0] to it.getOrElse(1) { "" } }
        return (if (vol == "primary") "/storage/emulated/0" else "/storage/$vol") + "/$rel"
    }

    private fun info(dir: String): Pair<String, List<String>> {
        val pm = listOf("pnpm-lock.yaml" to "pnpm", "yarn.lock" to "yarn", "bun.lockb" to "bun")
            .firstOrNull { File(dir, it.first).exists() }?.second ?: "npm"
        val s = runCatching {
            JSONObject(File(dir, "package.json").readText()).getJSONObject("scripts").keys().asSequence().sorted().toList()
        }.getOrDefault(emptyList())
        return pm to s
    }

    @Composable
    fun Screen() {
        val prefs = remember { getSharedPreferences("r", 0) }
        var dir by remember { mutableStateOf(prefs.getString("dir", "") ?: "") }
        var pm by remember { mutableStateOf("npm") }
        var scripts by remember { mutableStateOf(listOf<String>()) }
        var log by remember { mutableStateOf("Выбери папку проекта.\n") }
        var busy by remember { mutableStateOf(false) }
        var line by remember { mutableStateOf("") }
        val scroll = rememberScrollState()
        val ui = remember { Handler(Looper.getMainLooper()) }
        val proc = remember { arrayOfNulls<Process>(1) }
        val bin = remember { File(filesDir, "usr/bin").apply { mkdirs() }.path }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
            if (u != null) { dir = toPath(u); prefs.edit().putString("dir", dir).apply(); log = "" }
        }
        val pick = {
            if (!Environment.isExternalStorageManager())
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            else picker.launch(null)
        }

        LaunchedEffect(dir) {
            if (dir.isNotEmpty()) info(dir).let { pm = it.first; scripts = it.second }
        }
        LaunchedEffect(log) { scroll.scrollTo(scroll.maxValue) }

        fun run(cmd: String) {
            if (dir.isEmpty()) { pick(); return }
            val d = dir
            busy = true
            log += "$ $cmd\n"
            thread {
                val out = { s: String -> ui.post { log = (log + s).takeLast(200_000) } }
                try {
                    val pb = ProcessBuilder("sh", "-c", cmd).directory(File(d)).redirectErrorStream(true)
                    pb.environment().apply {
                        put("PATH", "$bin:${get("PATH")}")
                        put("HOME", filesDir.path)
                        put("NO_COLOR", "1")
                    }
                    val p = pb.start().also { proc[0] = it }
                    p.inputStream.bufferedReader().forEachLine { out(it + "\n") }
                    out("\n[код выхода: ${p.waitFor()}]\n")
                } catch (e: Exception) {
                    out("Ошибка: ${e.message}\n")
                }
                ui.post { busy = false }
            }
        }

        fun stop() {
            proc[0]?.let { p ->
                if (Build.VERSION.SDK_INT >= 33) p.toHandle().descendants().forEach { it.destroyForcibly() }
                p.destroyForcibly()
            }
        }

        val cmds = listOf("$pm install", "ls -la") + scripts.map { "$pm run $it" }

        Column(Modifier.fillMaxSize().background(BG).systemBarsPadding().imePadding()) {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { pick() }) {
                    Text(if (dir.isEmpty()) "Выбрать папку" else dir.substringAfterLast('/'))
                }
                Spacer(Modifier.weight(1f))
                if (busy) TextButton(onClick = { stop() }) { Text("Стоп", color = Color(0xFFF26D6D)) }
                TextButton(onClick = { log = "" }) { Text("Очистить") }
            }
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                cmds.forEach { FilledTonalButton(enabled = !busy, onClick = { run(it) }) { Text(it) } }
            }
            Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(scroll).padding(12.dp)) {
                Text(log, color = TXT, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 17.sp)
            }
            OutlinedTextField(
                value = line,
                onValueChange = { line = it },
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                placeholder = { Text("своя команда…") },
                prefix = { Text("$ ", color = ACC) },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { if (line.isNotBlank()) { run(line.trim()); line = "" } }),
            )
        }
    }
}